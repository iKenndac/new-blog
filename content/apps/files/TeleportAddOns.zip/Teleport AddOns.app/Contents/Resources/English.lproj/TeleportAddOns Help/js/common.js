function addFallbackClassNames() {
	var classNames = null;

	/* border image classes */
	classNames = new Array("bubble", "taskBubble", "callout");
	for (var i = 0; i < classNames.length; i++) {
		var className = classNames[i];
		var fallbackClassName = className + "Fallback";
		
		function _addFallbackClassName(e) {
			if (e.style["-webkit-border-image"] == null) {
				e.addClassName(fallbackClassName);
			}
		}
		
		$$("." + className).each(_addFallbackClassName);
	}
	
	/* border radius classes */
	classNames = new Array("token");
	for (var i = 0; i < classNames.length; i++) {
		var className = classNames[i];
		var fallbackClassName = className + "Fallback";
		
		function _addFallbackClassName(e) {
			if (e.style["-webkit-border-radius"] == null) {
				e.addClassName(fallbackClassName);
			}
		}
		
		$$("." + className).each(_addFallbackClassName);
	}
}

window.onload = function() {
	addFallbackClassNames();
}
